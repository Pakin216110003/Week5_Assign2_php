<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Ticket booking</title>
</head>
<body>
	

<table>
	<form action="Result.php" method="POST" >
	<tr>
		<td><input type="checkbox" name="a1" id="a1" value="A1">A1</td>
		<td><input type="checkbox" name="a2" id="a2">A2</td>
		<td><input type="checkbox" name="a3" id="a3">A3</td>
	</tr>
	<tr>
		<td><input type="checkbox" name="b1" id="b1" value="B1">B1</td>
		<td><input type="checkbox" name="b2" id="b2">B2</td>
		<td><input type="checkbox" name="b3" id="b3">B3</td>
	</tr>
	<tr>
		<td><input type="checkbox" name="c1" id="c1">C1</td>
		<td><input type="checkbox" name="c2" id="c2">C2</td>
		<td><input type="checkbox" name="c3" id="c3">C3</td>
	</tr>
	<tr>
		<td><input type="submit" value="Buy now!" ></td>
	</tr>

</table>

</body>
</html>