<?php

$NoSeats = 0;
$total = 0;
$a = 3000;
$b = 2000;
$c = 1000;

$receipt = array();

if(isset($_POST['a1'])){
	$result[$NoSeats] = "A1".": ". $a;
	$NoSeats +=1;
	$total += $a;
}

if(isset($_POST['b1'])){
	$result[$NoSeats] = "B1".": ". $b;
	$NoSeats +=1;
	$total += $b;
}

if(isset($_POST['c1'])){
	$result[$NoSeats] = "C1".": ". $c;
	$NoSeats +=1;
	$total += $c;
}
if(isset($_POST['a2'])){
	$result[$NoSeats] = "A2".": ". $a;
	$NoSeats +=1;
	$total += $a;
}

if(isset($_POST['b2'])){
	$result[$NoSeats] = "B2".": ". $b;
	$NoSeats +=1;
	$total += $b;
}

if(isset($_POST['c2'])){
	$result[$NoSeats] = "C2".": ". $c;
	$NoSeats +=1;
	$total += $c;
}
if(isset($_POST['a3'])){
	$result[$NoSeats] = "A3".": ". $a;
	$NoSeats +=1;
	$total += $a;
}

if(isset($_POST['b3'])){
	$result[$NoSeats] = "B3".": ". $b;
	$NoSeats +=1;
	$total += $b;
}

if(isset($_POST['c3'])){
	$result[$NoSeats] = "C3".": ". $c;
	$NoSeats +=1;
	$total += $c;
	
}

for ($i=0; $i < count($result); $i++) { 
	echo $result[$i]."<br>";
}

if($NoSeats == 0)
{
	echo "<div style='color: red'>Ticket is not selected</div>";
}
elseif ($NoSeats > 4) {
	echo "Ticket can only be bought for only 4 seats";
}
else{
	echo "Number of seats: ".$NoSeats."<br>";
	echo "Total Price: ".$total."<br>";
}

?>